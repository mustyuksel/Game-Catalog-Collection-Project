package org.example;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class Main extends Application {
    private static final double CELL_HEIGHT = 80; // Fixed cell height
    private static final double IMAGE_SIZE = 60;
    private ObservableList<Game> games;
    private FilteredList<Game> filteredGames;
    private ListView<Game> gameListView;
    private TextField searchField;
    @Override
    public void start(Stage stage) throws IOException {
        stage.setTitle("Game Management System");


        games = FXCollections.observableArrayList(FileHandler.readGames());


        filteredGames = new FilteredList<>(games, p -> true);


        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.TOP_CENTER);


        Label gmsTitle = new Label("Game Management System");
        gmsTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2A5058;");
        HBox titleHolder = new HBox(gmsTitle);
        titleHolder.setAlignment(Pos.CENTER_LEFT);
        titleHolder.setPadding(new Insets(0, 0, 10, 5));


        HBox mainFeatureHolder = new HBox(10);
        mainFeatureHolder.setAlignment(Pos.CENTER_LEFT);

        Button addButton = new Button("Add");
        Button editButton = new Button("Edit");
        Button deleteButton = new Button("Delete");
        Button importButton = new Button("Import");
        Button exportButton = new Button("Export");


        HBox searchBox = new HBox(5);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        searchField = new TextField();
        searchField.setPromptText("Search games...");
        Button clearButton = new Button("Clear");
        Button tagsButton = new Button("Tags");
        searchBox.getChildren().addAll(new Label("Search:"), searchField, clearButton, tagsButton);
        HBox.setHgrow(searchField, Priority.ALWAYS);

        mainFeatureHolder.getChildren().addAll(addButton, editButton, deleteButton, searchBox, importButton, exportButton);
        HBox.setHgrow(searchBox, Priority.ALWAYS);


        gameListView = new ListView<>();
        gameListView.setItems(filteredGames);
        gameListView.setFixedCellSize(CELL_HEIGHT);
        gameListView.setCellFactory(param -> new ListCell<Game>() {

            private final ImageView imageView = new ImageView();
            private final Text text = new Text();
            private final HBox hbox = new HBox(15, imageView, text); // 10 = spacing
            {
                imageView.setFitWidth(IMAGE_SIZE);
                imageView.setFitHeight(IMAGE_SIZE);
                imageView.setPreserveRatio(false);
            }
            @Override
            protected void updateItem(Game game, boolean empty) {
                super.updateItem(game, empty);
                if (empty || game == null) {
                    setGraphic(null);
                } else {
                    try {
                        imageView.setImage(FileHandler.loadCoverImage(game.getImagePath(),IMAGE_SIZE,IMAGE_SIZE));
                    } catch (Exception e) {
                        imageView.setImage(null); // Shows empty space
                    }
                    text.setText(game.getName() + "\n" + game.getDeveloper());
                    setGraphic(hbox); // Display HBox (image + text)
                }
            }
        });
        VBox.setVgrow(gameListView, Priority.ALWAYS);


        layout.getChildren().addAll(titleHolder, mainFeatureHolder, gameListView);


        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filterGames(newValue);
        });


        clearButton.setOnAction(e -> {
            searchField.clear();
        });


        addButton.setOnAction(e -> handleAddGame(stage));


        editButton.setOnAction(e -> handleEditGame(stage));


        deleteButton.setOnAction(e -> handleDeleteGame());



        Scene scene = new Scene(layout, 800, 600);
        stage.setScene(scene);
        stage.show();
    }


    private void filterGames(String searchText) {
        String lowerCaseFilter = searchText == null ? "" : searchText.toLowerCase().trim();

        filteredGames.setPredicate(game -> {

            if (lowerCaseFilter.isEmpty()) {
                return true;
            }


            if (game.getName().toLowerCase().contains(lowerCaseFilter)) {
                return true;
            } else if (game.getDeveloper().toLowerCase().contains(lowerCaseFilter)) {
                return true;
            }
            return false;
        });
    }



    private void handleAddGame(Stage owner) {
        GameDialog dialog = new GameDialog(owner);
        Optional<Game> result = dialog.showAndWaitForResult();

        result.ifPresent(newGame -> {
            try {
                FileHandler.addGame(newGame);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            games.add(newGame);
            gameListView.getSelectionModel().select(newGame);
            gameListView.scrollTo(newGame);
        });
    }

    private void handleEditGame(Stage owner) {
        Game selectedGame = gameListView.getSelectionModel().getSelectedItem();
        String tempOldName = selectedGame.getName();
        if (selectedGame == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a game to edit.");
            return;
        }

        GameDialog dialog = new GameDialog(owner, selectedGame);
        Optional<Game> result = dialog.showAndWaitForResult();

        result.ifPresent(editedGame -> {
            try {
                FileHandler.deleteGame(tempOldName);
                FileHandler.addGame(editedGame);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            gameListView.refresh();

            gameListView.getSelectionModel().select(editedGame);
        });
    }

    private void handleDeleteGame(){
        Game selectedGame = gameListView.getSelectionModel().getSelectedItem();
        if (selectedGame == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a game to delete.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Deletion");
        confirmation.setHeaderText("Delete Game: " + selectedGame.getName());
        confirmation.setContentText("Are you sure you want to delete this game? This action cannot be undone.");
        confirmation.initOwner(gameListView.getScene().getWindow());

        Optional<ButtonType> result = confirmation.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                FileHandler.deleteGame(selectedGame.getName());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            games.remove(selectedGame);
        }
    }


    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(gameListView.getScene().getWindow());
        alert.showAndWait();
    }


    public static void main(String[] args) {
        launch(args);
    }

}