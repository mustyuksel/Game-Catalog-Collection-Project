package org.example;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.util.Optional;


public class GameDialog extends Stage {

    private final TextField nameField = new TextField();
    private final TextField developerField = new TextField();
    private Game resultGame = null; // To store the result


    public GameDialog(Window owner) {
        this(owner, null);
    }


    public GameDialog(Window owner, Game gameToEdit) {
        initOwner(owner);
        initModality(Modality.WINDOW_MODAL);

        setTitle(gameToEdit == null ? "Add New Game" : "Edit Game");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        GridPane.setHgrow(nameField, javafx.scene.layout.Priority.ALWAYS);

        grid.add(new Label("Developer:"), 0, 1);
        grid.add(developerField, 1, 1);
        GridPane.setHgrow(developerField, javafx.scene.layout.Priority.ALWAYS);


        if (gameToEdit != null) {
            nameField.setText(gameToEdit.getName());
            developerField.setText(gameToEdit.getDeveloper());
        }

        Button saveButton = new Button("Save");
        saveButton.setDefaultButton(true);
        saveButton.setOnAction(e -> saveAndClose(gameToEdit));

        Button cancelButton = new Button("Cancel");
        cancelButton.setCancelButton(true);
        cancelButton.setOnAction(e -> close());

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
        buttonBox.getChildren().addAll(cancelButton, saveButton);
        grid.add(buttonBox, 1, 2);

        Scene scene = new Scene(grid);
        setScene(scene);
        sizeToScene();
        setResizable(false);
    }


    private void saveAndClose(Game gameToEdit) {
        String name = nameField.getText().trim();
        String developer = developerField.getText().trim();


        if (name.isEmpty() || developer.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Validation Error");
            alert.setHeaderText(null);
            alert.setContentText("Please enter both name and developer.");
            alert.initOwner(this);
            alert.showAndWait();
            return;
        }

        if (gameToEdit == null) {

            resultGame = new Game(name, developer);
        } else {

            gameToEdit.setName(name);
            gameToEdit.setDeveloper(developer);
            resultGame = gameToEdit;
        }
        close();
    }


    public Optional<Game> showAndWaitForResult() {
        showAndWait();
        return Optional.ofNullable(resultGame);
    }
}
