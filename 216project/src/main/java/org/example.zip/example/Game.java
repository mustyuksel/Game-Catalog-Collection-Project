package org.example;

public class Game {
    private String imagePath;
    private String name;
    private String genre;
    private String developer;
    private String publisher;
    private String platforms;
    private String steamid;
    private String releaseYear;
    private String playtime;
    private String format;
    private String language;
    private int rating;
    private String[] tags;

    public Game(String name, String developer) {
        this.name = name;
        this.developer = developer;
    }

    public String getName() { return name; }
    public String getDeveloper() { return developer; }
    public String getImagePath() { return imagePath; }


    public void setName(String name) { this.name = name; }
    public void setDeveloper(String developer) { this.developer = developer; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    @Override
    public String toString() {

        return name + " (by " + developer + ")";
    }


}